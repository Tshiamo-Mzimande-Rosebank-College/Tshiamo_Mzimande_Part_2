import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;
import java.util.regex.*;

public class TshiamoMzimande_Part_2Test {
    
    // Test data
    private String testPhoneValid = "+27718693002";
    private String testPhoneInvalid = "08575975889";
    private String testMessageShort = "Hi Mike, can you join us for dinner tonight?";
    private String testMessageLong;
    
    public TshiamoMzimande_Part_2Test() {
        // Create long message (260 characters)
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            builder.append("X");
        }
        testMessageLong = builder.toString();
    }
    
    @BeforeClass
    public static void setupSuite() {
        System.out.println("=========================================");
        System.out.println("   CHATTER SYSTEM - UNIT TEST SUITE");
        System.out.println("=========================================");
    }
    
    @AfterClass
    public static void teardownSuite() {
        System.out.println("\n=========================================");
        System.out.println("         ALL TESTS COMPLETED");
        System.out.println("=========================================");
    }
    
    @Before
    public void beforeEach() {
        System.out.println("\n> Running test...");
    }
    
    @After
    public void afterEach() {
        System.out.println("< Test finished.");
    }
    
    // TEST 1: Message Length - PASS
    @Test
    public void checkShortMessageLength() {
        System.out.println("\n[TEST 1] Valid message length check");
        
        boolean isValid = testMessageShort.length() <= 250;
        
        assertTrue("Message should be under 250 chars", isValid);
        System.out.println("   Result: Message ready to send.");
        System.out.println("   Length: " + testMessageShort.length() + " characters");
    }
    
    // TEST 2: Message Length - FAIL
    @Test
    public void checkLongMessageLength() {
        System.out.println("\n[TEST 2] Invalid message length check");
        
        int excess = testMessageLong.length() - 250;
        boolean isInvalid = testMessageLong.length() > 250;
        
        assertTrue("Message should exceed 250 chars", isInvalid);
        System.out.println("   Result: Message exceeds 250 characters by " + excess + "; please reduce the size.");
    }
    
    // TEST 3: SA Number - PASS
    @Test
    public void checkValidSaNumber() {
        System.out.println("\n[TEST 3] Valid SA phone number");
        
        Pattern p = Pattern.compile("^((\\+27)|0)[678][0-9]{8}$");
        boolean matches = p.matcher(testPhoneValid).matches();
        
        assertTrue("Phone should be valid", matches);
        System.out.println("   Result: Cell phone number successfully captured.");
        System.out.println("   Number: " + testPhoneValid);
    }
    
    // TEST 4: SA Number - FAIL
    @Test
    public void checkInvalidSaNumber() {
        System.out.println("\n[TEST 4] Invalid SA phone number");
        
        Pattern p = Pattern.compile("^((\\+27)|0)[678][0-9]{8}$");
        boolean matches = p.matcher(testPhoneInvalid).matches();
        
        assertFalse("Phone should be invalid", matches);
        System.out.println("   Result: Cell phone number is incorrectly formatted.");
        System.out.println("   Number entered: " + testPhoneInvalid);
    }
    
    // TEST 5: Message Hash Generation
    @Test
    public void verifyHashGeneration() {
        System.out.println("\n[TEST 5] Message hash creation");
        
        String mockId = "0047291836";
        int msgNum = 0;
        String msgText = "Hi Mike, can you join us for dinner tonight?";
        
        String prefix = mockId.substring(0, 2);
        String[] words = msgText.trim().split("\\W+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length-1].toUpperCase();
        
        String generated = prefix + ":" + msgNum + ":" + firstWord + lastWord;
        String expected = "00:0:HITONIGHT";
        
        assertEquals("Hash should match expected pattern", expected, generated);
        System.out.println("   Generated: " + generated);
        System.out.println("   Hash is correct!");
    }
    
    // TEST 6: Multiple Hashes Loop
    @Test
    public void loopThroughMultipleHashes() {
        System.out.println("\n[TEST 6] Testing multiple message hashes");
        
        String[] fakeIds = {"0047291836", "0058392047", "0061749352"};
        int[] nums = {0, 1, 2};
        String[] texts = {
            "Hi Mike, can you join us for dinner tonight?",
            "Hello John, meeting scheduled",
            "Good morning team, please reply"
        };
        
        for (int i = 0; i < fakeIds.length; i++) {
            String prefix = fakeIds[i].substring(0, 2);
            String[] splitWords = texts[i].trim().split("\\W+");
            String first = splitWords[0].toUpperCase();
            String last = splitWords[splitWords.length-1].toUpperCase();
            String result = prefix + ":" + nums[i] + ":" + first + last;
            
            System.out.println("   Hash " + (i+1) + ": " + result);
            assertTrue("Hash should contain colons", result.contains(":"));
        }
        System.out.println("   All hashes formatted correctly!");
    }
    
    // TEST 7: ID Generation
    @Test
    public void checkIdGeneration() {
        System.out.println("\n[TEST 7] Unique ID creation");
        
        Random r = new Random();
        long idNum = 1000000000L + (long)(r.nextDouble() * 9000000000L);
        String generatedId = String.valueOf(idNum);
        
        System.out.println("   Generated ID: " + generatedId);
        
        assertEquals("ID must be 10 digits", 10, generatedId.length());
        assertTrue("ID must be numeric", generatedId.matches("\\d+"));
        
        System.out.println("   ID creation successful!");
    }
    
    // TEST 8: Send Option
    @Test
    public void checkSendOption() {
        System.out.println("\n[TEST 8] Send message option");
        
        String userChoice = "1";
        String expected = "Message sent successfully!";
        String actual = "";
        
        if (userChoice.equals("1")) {
            actual = "Message sent successfully!";
        }
        
        assertEquals("Send option should return success", expected, actual);
        System.out.println("   User selected: Send");
        System.out.println("   Response: " + actual);
    }
    
    // TEST 9: Discard Option
    @Test
    public void checkDiscardOption() {
        System.out.println("\n[TEST 9] Discard message option");
        
        String userChoice = "2";
        String expected = "Message discarded.";
        String actual = "";
        
        if (userChoice.equals("2")) {
            actual = "Message discarded.";
        }
        
        assertEquals("Discard option should return discard message", expected, actual);
        System.out.println("   User selected: Discard");
        System.out.println("   Response: " + actual);
    }
    
    // TEST 10: Store Option
    @Test
    public void checkStoreOption() {
        System.out.println("\n[TEST 10] Store message option");
        
        String userChoice = "3";
        String expected = "Message saved to storage.";
        String actual = "";
        
        if (userChoice.equals("3")) {
            actual = "Message saved to storage.";
        }
        
        assertEquals("Store option should return storage message", expected, actual);
        System.out.println("   User selected: Store");
        System.out.println("   Response: " + actual);
    }
    
    // TEST 11: Complete Test Data
    @Test
    public void validateAssignmentData() {
        System.out.println("\n[TEST 11] Validating assignment test data");
        
        int totalMessages = 2;
        System.out.println("   Total messages: " + totalMessages);
        
        // Message 1 validation
        String msg1 = "Hi Mike, can you join us for dinner tonight?";
        System.out.println("\n   Message 1:");
        System.out.println("      Recipient: +27718693002");
        System.out.println("      Content: \"" + msg1 + "\"");
        System.out.println("      Length check: " + msg1.length() + "/250 chars");
        assertTrue(msg1.length() <= 250);
        
        // Message 2 validation
        String msg2 = "Hi Keegan, did you receive the payment?";
        System.out.println("\n   Message 2:");
        System.out.println("      Recipient: 08575975889");
        System.out.println("      Content: \"" + msg2 + "\"");
        System.out.println("      Length check: " + msg2.length() + "/250 chars");
        assertTrue(msg2.length() <= 250);
        
        System.out.println("\n   All test data validated!");
    }
    
    // TEST 12: Auto Generation Check
    @Test
    public void verifyAutoGeneratedFields() {
        System.out.println("\n[TEST 12] Auto-generated fields verification");
        
        // Simulate auto-generated values
        int sentCount = 1;
        String msgHash = "00:0:HITONIGHT";
        String msgId = "4728193650";
        
        System.out.println("   Num sent (auto): " + sentCount);
        System.out.println("   Message Hash (auto): " + msgHash);
        System.out.println("   Message ID (auto): " + msgId);
        
        assertTrue("Sent count should be positive", sentCount > 0);
        assertNotNull("Hash should not be null", msgHash);
        assertFalse("Hash should not be empty", msgHash.isEmpty());
        assertEquals("ID should be 10 digits", 10, msgId.length());
        
        System.out.println("   All auto fields verified!");
    }
    
    // TEST 13: Total Messages Count
    @Test
    public void checkTotalMessagesCount() {
        System.out.println("\n[TEST 13] Total messages count verification");
        
        int sentMessages = 1;
        int expectedTotal = 1;
        
        System.out.println("   Total messages sent: " + sentMessages);
        
        assertEquals("Total sent should match expected", expectedTotal, sentMessages);
        System.out.println("   Count verification passed!");
    }
}