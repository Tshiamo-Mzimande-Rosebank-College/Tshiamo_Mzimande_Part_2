package com.mycompany.tshiamomzimande_part_2;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

public class TshiamoMzimande_Part_2 {
    
    // Arrays to store message data
    private static ArrayList<String> storedIds = new ArrayList<>();
    private static ArrayList<String> storedHashes = new ArrayList<>();
    private static ArrayList<String> storedRecipients = new ArrayList<>();
    private static ArrayList<String> storedMessages = new ArrayList<>();
    private static ArrayList<String> storedStatus = new ArrayList<>();
    
    private static Scanner input = new Scanner(System.in);
    
    // SA phone number regex: matches 0712345678 or +27712345678
    private static final Pattern SA_PATTERN = Pattern.compile("^((\\+27)|0)[678][0-9]{8}$");
    
    // JSON file storage
    private static final String JSON_FILE = "messages.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    
    // User credentials
    private static String savedUser = "";
    private static String savedPass = "";
    private static boolean userRegistered = false;
    
    public static void main(String[] args) {
        System.out.println("WELCOME TO CHATTER");
        
        boolean loggedIntoSystem = false;
        
        while (!loggedIntoSystem) {
            showMainOptions();
            String userDecision = input.nextLine();
            
            switch (userDecision) {
                case "1":
                    createNewAccount();
                    break;
                case "2":
                    if (userRegistered) {
                        loggedIntoSystem = verifyLogin();
                    } else {
                        System.out.println("No account found. Please register first.");
                    }
                    break;
                case "3":
                    System.out.println("Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid selection. Try again.");
            }
        }
        
        startMessagingSystem();
    }
    
    // Displays main menu options
    private static void showMainOptions() {
        System.out.println("\n[MAIN MENU]");
        System.out.println("1. Create New Account");
        System.out.println("2. Sign In");
        System.out.println("3. Exit Application");
        System.out.print("Choose an option: ");
    }
    
    // Registers a new user
    private static void createNewAccount() {
        System.out.println("\nREGISTRATION FORM");
        System.out.print("Choose username: ");
        savedUser = input.nextLine();
        System.out.print("Choose password: ");
        savedPass = input.nextLine();
        userRegistered = true;
        System.out.println("Account created successfully!");
    }
    
    // Verifies user login credentials
    private static boolean verifyLogin() {
        System.out.println("\nLOGIN SCREEN");
        System.out.print("Username: ");
        String enteredUser = input.nextLine();
        System.out.print("Password: ");
        String enteredPass = input.nextLine();
        
        if (enteredUser.equals(savedUser) && enteredPass.equals(savedPass)) {
            System.out.println("Access granted!");
            return true;
        } else {
            System.out.println("Access denied. Incorrect credentials.");
            return false;
        }
    }
    
    // Main messaging system
    private static void startMessagingSystem() {
        System.out.println("\nWelcome to Chatter Messaging System");
        
        int msgLimit = 0;
        while (msgLimit <= 0) {
            System.out.print("How many messages would you like to create? ");
            try {
                msgLimit = Integer.parseInt(input.nextLine());
                if (msgLimit <= 0) {
                    System.out.println("Please enter a number greater than zero.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format. Try again.");
            }
        }
        
        int sentTotal = 0;
        int storedTotal = 0;
        int discardedTotal = 0;
        
        boolean appRunning = true;
        while (appRunning) {
            showMessagingMenu();
            String menuPick = input.nextLine();
            
            switch (menuPick) {
                case "1":
                    // Process each message
                    for (int cycle = 0; cycle < msgLimit; cycle++) {
                        System.out.println("\nMESSAGE " + (cycle + 1) + " of " + msgLimit);
                        
                        String phoneNumber = capturePhoneNumber();
                        String messageBody = captureMessageContent();
                        
                        ChatterMessage newMsg = new ChatterMessage(cycle + 1, phoneNumber, messageBody);
                        
                        displayPreview(newMsg);
                        
                        String userAction = getUserAction();
                        System.out.println(userAction);
                        
                        if (userAction.equals("Message sent successfully!")) {
                            storedIds.add(newMsg.getMessageId());
                            storedHashes.add(newMsg.getMessageHash());
                            storedRecipients.add(newMsg.getRecipient());
                            storedMessages.add(newMsg.getText());
                            storedStatus.add("delivered");
                            sentTotal++;
                        } else if (userAction.equals("Message discarded.")) {
                            discardedTotal++;
                        } else if (userAction.equals("Message saved to storage.")) {
                            storedIds.add(newMsg.getMessageId());
                            storedHashes.add(newMsg.getMessageHash());
                            storedRecipients.add(newMsg.getRecipient());
                            storedMessages.add(newMsg.getText());
                            storedStatus.add("archived");
                            storedTotal++;
                            newMsg.archiveToJson();
                        }
                    }
                    
                    printFinalSummary(sentTotal, storedTotal, discardedTotal, msgLimit);
                    
                    System.out.print("\nPress Enter to continue or type 'quit' to exit: ");
                    String continueChoice = input.nextLine();
                    if (continueChoice.equalsIgnoreCase("quit")) {
                        appRunning = false;
                    }
                    break;
                    
                case "2":
                    System.out.println("Feature under development - Coming soon!");
                    break;
                    
                case "3":
                    System.out.println("Logging out. Goodbye!");
                    appRunning = false;
                    break;
                    
                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }
        }
        
        input.close();
    }
    
    // Displays messaging menu
    private static void showMessagingMenu() {
        System.out.println("\n[CHATTER MENU]");
        System.out.println("1. Compose & Send Message");
        System.out.println("2. View Recent Messages");
        System.out.println("3. Exit Application");
        System.out.print("Your selection: ");
    }
    
    // Validates and captures SA phone number
    private static String capturePhoneNumber() {
        String number = "";
        boolean valid = false;
        
        while (!valid) {
            System.out.print("Recipient's SA number (e.g., 0712345678): ");
            number = input.nextLine();
            String cleaned = number.replaceAll("[\\s-]", "");
            
            if (SA_PATTERN.matcher(cleaned).matches()) {
                valid = true;
            } else {
                System.out.println("Invalid format! Use 0712345678 or +27712345678");
            }
        }
        return number;
    }
    
    // Validates and captures message content (max 250 chars)
    private static String captureMessageContent() {
        String msg = "";
        boolean good = false;
        
        while (!good) {
            System.out.print("Type your message (max 250 characters): ");
            msg = input.nextLine();
            
            if (msg.length() <= 250) {
                good = true;
            } else {
                int extra = msg.length() - 250;
                System.out.println("Too long! Exceeds by " + extra + " characters. Please shorten.");
            }
        }
        return msg;
    }
    
    // Displays message preview
    private static void displayPreview(ChatterMessage msg) {
        System.out.println("\n[MESSAGE PREVIEW]");
        System.out.println(msg.previewMessage());
    }
    
    // Gets user action for message (send, discard, store)
    private static String getUserAction() {
        System.out.println("\n[OPTIONS FOR MESSAGE]");
        System.out.println("1. Send immediately");
        System.out.println("2. Throw away");
        System.out.println("3. Save for later (JSON)");
        System.out.print("Pick an option (1-3): ");
        
        String decision = input.nextLine();
        
        switch (decision) {
            case "1": return "Message sent successfully!";
            case "2": return "Message discarded.";
            case "3": return "Message saved to storage.";
            default: return "Invalid. Please try again.";
        }
    }
    
    // Prints final summary report
    private static void printFinalSummary(int sent, int stored, int discarded, int total) {
        System.out.println("\n[FINAL REPORT]");
        System.out.println("Messages sent:      " + sent);
        System.out.println("Messages stored:    " + stored);
        System.out.println("Messages discarded: " + discarded);
        System.out.println("Total processed:    " + total);
        
        if (storedIds.size() > 0) {
            System.out.println("\nARCHIVED MESSAGES:");
            for (int i = 0; i < storedIds.size(); i++) {
                System.out.println("\nMessage " + (i+1));
                System.out.println("   ID: " + storedIds.get(i));
                System.out.println("   Hash: " + storedHashes.get(i));
                System.out.println("   Recipient: " + storedRecipients.get(i));
                System.out.println("   Text: " + storedMessages.get(i));
                System.out.println("   Status: " + storedStatus.get(i));
            }
        }
    }
    
    // ==================== INNER CLASS FOR MESSAGE ====================
    
    static class ChatterMessage {
        private String uid;           // Unique message ID
        private int sequence;         // Message number
        private String destination;   // Recipient phone number
        private String content;       // Message text
        private String securityHash;  // Generated hash
        private String condition;     // Message status
        
        // Constructor
        public ChatterMessage(int seq, String phone, String msg) {
            this.sequence = seq;
            this.destination = phone;
            this.content = msg;
            this.uid = createUniqueId();
            this.securityHash = generateHashCode();
            this.condition = "draft";
        }
        
        // Generates random 10-digit message ID
        private String createUniqueId() {
            Random rand = new Random();
            long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
            return String.valueOf(id);
        }
        
        // Generates message hash: firstTwoDigits:sequenceNumber:FIRSTWORDLASTWORD
        private String generateHashCode() {
            String prefix = this.uid.substring(0, 2);
            String[] words = this.content.trim().split("\\W+");
            String first = words.length > 0 ? words[0].toUpperCase() : "";
            String last = words.length > 1 ? words[words.length-1].toUpperCase() : first;
            return prefix + ":" + this.sequence + ":" + first + last;
        }
        
        // Returns formatted message preview
        public String previewMessage() {
            return "ID: " + this.uid + "\n" +
                   "Hash: " + this.securityHash + "\n" +
                   "To: " + this.destination + "\n" +
                   "Msg: " + this.content;
        }
        
        // Saves message to JSON file
        public void archiveToJson() {
            try {
                List<Map<String, Object>> messageArchive = new ArrayList<>();
                File jsonFile = new File(JSON_FILE);
                
                // Read existing messages if file exists
                if (jsonFile.exists()) {
                    String existingContent = new String(Files.readAllBytes(Paths.get(JSON_FILE)));
                    if (!existingContent.trim().isEmpty()) {
                        messageArchive = gson.fromJson(existingContent, new TypeToken<List<Map<String, Object>>>(){}.getType());
                    }
                }
                
                // Create new message record
                Map<String, Object> messageRecord = new LinkedHashMap<>();
                messageRecord.put("messageId", this.uid);
                messageRecord.put("messageNumber", this.sequence);
                messageRecord.put("messageHash", this.securityHash);
                messageRecord.put("recipient", this.destination);
                messageRecord.put("message", this.content);
                messageRecord.put("status", this.condition);
                messageRecord.put("timestamp", new Date().toString());
                
                messageArchive.add(messageRecord);
                
                // Write to JSON file
                String jsonOutput = gson.toJson(messageArchive);
                Files.write(Paths.get(JSON_FILE), jsonOutput.getBytes());
                
                System.out.println("JSON file saved to: " + new File(JSON_FILE).getAbsolutePath());
                
            } catch (IOException e) {
                System.out.println("Error saving to JSON: " + e.getMessage());
            }
        }
        
        // Getters
        public String getMessageId() { return uid; }
        public String getMessageHash() { return securityHash; }
        public String getRecipient() { return destination; }
        public String getText() { return content; }
        public String getStatus() { return condition; }
    }
}